﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectPruefungQuezSpiel
{
    class DBCommandClass
    {
        public List<LaenderClass>  laenderIN()
        {
             List<LaenderClass> spiel = new List<LaenderClass>();


            return spiel;
        }

        public void saveErgabniss()
        {

        }
    }
}
