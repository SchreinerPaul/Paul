﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectPruefungQuezSpiel
{
    public partial class Form1 : Form
    {
        DBBefehleClass db = new DBBefehleClass();
        List<LaenderClass> spiel = new List<LaenderClass>();
        List<List <int>> erg = new List<List<int>>();
        List<Button> buLi1 = new List<Button>(), buLi2 = new List<Button>();
        List<Label> labLi = new List<Label>();
        Color defaultBorderColor = new Color();
        int button12XRight, button12Width, button7Width, button11XLeft;
        int n, count, spielart;
        public bool log { get; set; }
        public SpielerClass spl { get; set; }
        public Form1()
        {
            InitializeComponent();            
            laendeTabelleFuelen();
            defaultBorderColor = button1.FlatAppearance.BorderColor;
            
            button12XRight = button12.Location.X + button12.Size.Width;
            button12Width = button12.Size.Width;
            button7Width = button7.Size.Width;
            button11XLeft = button11.Location.X;

            logIn();
            spiel = db.laenderIN();//Datenbank wird, falls er nicht da ist, angelegt und mit Länder/Flagen/Städten gefühlt

            //Buttongruppe für Spielauswahl  
            buLi1.Add(button1); buLi1.Add(button2); buLi1.Add(button3);
            buLi1.Add(button4); buLi1.Add(button5); buLi1.Add(button6);

            //Buttongruppe für Antwortenauswahl  
            buLi2.Add(button7); buLi2.Add(button8); buLi2.Add(button9);buLi2.Add(button10);

            //Lablegruppe mit Haken für Richtig/Falsch
            labLi.Add(label8); labLi.Add(label9); labLi.Add(label10); labLi.Add(label11);

            label1.Focus();
        }

        public void logIn() // Führt Login aus (über login Form)
        {
            label5.Text = "";
            log = false;
            this.Hide();
            do
            {
                login l = new login(this);
                l.ShowDialog();
            } while (!log);
            label1.Text = "Nickname: " + spl.NickName;
            label3.Text = "Beste Ergebnisse von " + spl.NickName;
            scoreList();
            this.Show();
        }       

        public void scoreList() //Scroreliste wird von Datenbank gelesen und in der ListBoxen geschriben
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            List<List<string>> forALL = db.bestForAllListe();// Ergebnissliste für alle            
            foreach(List <string> zeile in forALL)
            {
                string tab = "";
                for (int i = 0; i < 35 - zeile[0].Length; i++)
                    tab += " ";
                listBox1.Items.Add($"{zeile[0]}{tab}\t{zeile[1]}");
            }
            List<List<string>> forME = db.bestForMeListe(spl.NickName); // Ergebnissliste für spieler
            foreach (List<string> zeile in forME)
            {
                string tab = "";
                for (int i = 0; i < 32 - zeile[0].Length; i++) tab += " ";
                listBox2.Items.Add($"{zeile[0]}{tab}\t{zeile[1]}");
            }            
        }
        
        public void texVisibility (int bed) //Umschalten zwieschen Spielauswahl und der Spiel selbst
        {
            if (bed == 0)
            {
                foreach (Button b in buLi1) b.Hide();
                foreach (Button b in buLi2) b.Show();
                button12.Show();                
            }

            if (bed == 1)
            {
                foreach (Button b in buLi1) b.Show();
                foreach (Button b in buLi2) b.Hide();
                button12.Hide();
            }
        }

        public void rnd () //Auswahl von bespielten Ländern. 10 mal 4 und zu jeder 4rer Nummer der Richtiger dazu
        {
            erg.Clear();
            List<int> ll = new List<int>() ; // Zahlenliste mit Nummer der Länder
            for(int i = 0; i < spiel.Count; i++) ll.Add(i);
            Random zufall = new Random();
            for (int j = 0; j < 10; j++)
            {
                List <int> tour = new List <int>();
                for (int i = 0; i < 4; i++)
                {

                    int r = zufall.Next(0, ll.Count );
                    tour.Add(ll[r]);
                    ll.Remove(ll[r]);  //der ausgewähle Nummer wir aus Auslösungsliste gelösch um Wiederholungen zu vermeiden  
                }
                tour.Add(zufall.Next(0, 4)); // Auswahl der richtigen aus 4rer Listen. Wird in der selber liste an letzten Platz gespeichert
                erg.Add(tour);
            }           
        }

        public void derSpiel (bool bedingung) //Spielstart /-ende Procedur
        {
            if (bedingung)              //true ist Spielanfang
            {
                texVisibility(0);
                label5.Hide();
                count = 0;            
                n=0;
                rnd();
                button12.BackgroundImage = null;                   
                foreach (Button b in buLi2 ) b.BackgroundImage = null;
                auffuelen();
            }
            else                        //false ist Spielende 
            {
                texVisibility(1);
                label5.Text = $"{spl.NickName},\nSie haben in letzen Spiel\n{count} von 10 richtig geraten";
                label5.Show();
                label6.Text = "";
                db.saveErgabniss(spl.Id, count);
                scoreList();
                label1.Focus();
            }
        }

        public void auffuelen ()   //Fragelabel und  Anwort-Tabs  werden mit Daten in Abhängigkeit von der Spielart gefühlt.
        {
            label6.Text = $"Tour Nummer {n + 1} von 10 ";
            switch (spielart)
            {
                case 1:
                    button12.AutoSize = true;
                    button12.Text = spiel[erg[n][erg[n][4]]].Land;
                    for (int i = 0; i < 4; i++)
                    {
                        buLi2[i].AutoSize = true;
                        buLi2[i].Text = spiel[erg[n][i]].Hauptstadt;
                    }
                    break;
                case 2:
                    button12.AutoSize = true;
                    button12.Text = spiel[erg[n][erg[n][4]]].Land;
                    for (int i = 0; i < 4; i++)
                    {
                        buLi2[i].Text = "";
                        buLi2[i].AutoSize = false;
                        buLi2[i].BackgroundImage = Image.FromFile($"flags-normal\\{spiel[erg[n][i]].Flagge.ToLower()}.png");
                    }
                    break;
                case 3: 
                    button12.AutoSize = true;
                    button12.Text = spiel[erg[n][erg[n][4]]].Hauptstadt;
                    for (int i = 0; i < 4; i++)
                    {
                        buLi2[i].AutoSize = true;
                        buLi2[i].Text = spiel[erg[n][i]].Land;
                    }
                    break;
                case 4:
                    button12.AutoSize = true;
                    button12.Text = spiel[erg[n][erg[n][4]]].Hauptstadt;
                    for (int i = 0; i < 4; i++)
                    {
                        buLi2[i].Text = "";
                        buLi2[i].AutoSize = false;
                        buLi2[i].BackgroundImage = Image.FromFile($"flags-normal\\{spiel[erg[n][i]].Flagge.ToLower()}.png");
                    }
                    break;
                case 5:
                    button12.AutoSize = false;
                    button12.BackgroundImage = Image.FromFile($"flags-normal\\{spiel[erg[n][erg[n][4]]].Flagge.ToLower()}.png");
                    button12.Text = "";
                    for (int i = 0; i < 4; i++)
                    {
                        buLi2[i].Text = spiel[erg[n][i]].Hauptstadt;
                    }
                    break;
                case 6:
                    button12.AutoSize = false;
                    button12.BackgroundImage = Image.FromFile($"flags-normal\\{spiel[erg[n][erg[n][4]]].Flagge.ToLower()}.png");
                    button12.Text = "";
                    for (int i = 0; i < 4; i++)
                    {
                        buLi2[i].AutoSize = true;
                        buLi2[i].Text = spiel[erg[n][i]].Land;
                    }
                    break;
            }
            button12.Left = button12XRight - button12.Size.Width;
            button11.Left = (Math.Max(button8.Width, button9.Width) - button7Width) + button11XLeft;
        }

        public void click(int butNummer) // trifft bei einer Antwort-Auswahl
        {
            foreach (Button b in buLi2) b.Enabled = false; //verbot von zweiten Antwort zu der selbe Frage

            //richtiger Antwort wird Farbig markiert
            buLi2[erg[n][4]].FlatAppearance.BorderColor = Color.Lime;            
            labLi[erg[n][4]].ForeColor = Color.LimeGreen;            
            labLi[erg[n][4]].Text = "ü";
            labLi[erg[n][4]].Show();            

            if (erg[n][4] == butNummer)
            {
                count++; //Punkterhöhung               
            }
            else
            {
                // falsche Antwort wird Farbig markiert
                buLi2[butNummer].FlatAppearance.BorderColor = Color.Red;
                labLi[butNummer].Show();                
                labLi[butNummer].ForeColor = Color.Red;
                labLi[butNummer].Text = "û";                
            }
            button11.Show();//weiter button
            n++; //Fragenzeller
        }

        private void button11_Click(object sender, EventArgs e) // Button "Weiter" 
        {
            button12.Width = button12Width;
            foreach (Button b in buLi2)
            {
                // Fragebutton werden in Anfagszustand gesezt
                b.FlatAppearance.BorderColor = Color.DarkGray;
                b.Enabled = true;
                b.Text = "";
                b.Width = button7Width;
                button11.Left = button11XLeft;
            }
            foreach (Label l in labLi) l.Hide();
            button11.Hide();
            if (n >= 10) //Prüfung ob der Spiel durch ist
            { derSpiel(false); }
            else auffuelen();
            label1.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            spielart = 1;
            derSpiel(true);
        } // Spielauswahl butoon N 0
        private void button2_Click(object sender, EventArgs e)
        {
            spielart = 2;
            derSpiel(true);
        } // Spielauswahl butoon N 1
        private void button3_Click(object sender, EventArgs e)
        {
            spielart = 3;
            derSpiel(true);
        } // Spielauswahl butoon N 2
        private void button4_Click(object sender, EventArgs e)
        {
            spielart = 4;
            derSpiel(true);
        } // Spielauswahl butoon N 3
        private void button5_Click(object sender, EventArgs e)
        {
            spielart = 5;
            derSpiel(true);
        } // Spielauswahl butoon N 4
        private void button6_Click(object sender, EventArgs e)
        {
            spielart = 6;
            derSpiel(true);
        } // Spielauswahl butoon N 5

        private void button14_Click(object sender, EventArgs e)//Ende button
        {
            Application.Exit();
        }
        private void button7_Click(object sender, EventArgs e) // listNummer: 0
        {
            click(0);
        }       
        private void button8_Click(object sender, EventArgs e) // listNummer: 1
        {
            click(1);
        }
        private void button9_Click(object sender, EventArgs e) // listNummer: 2
        {
            click(2);
        }
        private void button10_Click(object sender, EventArgs e) // listNummer: 3
        {
            click(3);
        }

        private void button13_Click(object sender, EventArgs e) //logOUT button
        {
            logIn();
        }

        // Da die Länder Namem und Länderflagen aus verschiedenen Quelen kommen 
        // und der Länder-Datei mehr Länder aufweist als der Flagen-Ordner Flage hat, 
        // wird unter anderem auch nachgeschaut das es nur die länder zu Spiel zugelassen werden
        // zu den auf einen Flagen-Abbbildung orhanden ist

        List<string> liFlag = new List<string>(); //hier wird Liste mit Nammen alle vorhandenen LanderFanen plaziert
        public void laendeTabelleFuelen() // 
        {
            db.datenbankCheck();//Datenbank wird erstelt, falls er nicht da ist

            FileStream ff = new FileStream("flagNamen.txt", FileMode.Open, FileAccess.Read);
            StreamReader ss = new StreamReader(ff);
            while (ss.Peek() != -1)
            {
                string zeile = ss.ReadLine();
                liFlag.Add(zeile);
            }
            ss.Close();
            ff.Close();
            
            FileStream fs = new FileStream("Mappe2.txt",FileMode.Open,FileAccess.Read);//datei mit Ländernamen/Haupstädten/flagen-Kürzeln
            StreamReader sr = new StreamReader(fs);

            while (sr.Peek() != -1) //LÄndernamen werden angelesen
            {
                string zeile = sr.ReadLine();
                string[] w = zeile.Split( '\t');
                string[] w2 = new string[3];
                int i = 0;
                foreach (string ww in w)
                {
                    if (ww != "" && ww != " " && ww != ":")
                    {
                        w2[i] = ww;
                        i++;
                    }
                }
                foreach (string f in liFlag)//Datenbanktabelle Laende wird gefühlt
                {
                    if(w2[0].ToLower() == f) db.saveLandFlagStadt(w2[1], w2[2], w2[0].ToLower());
                }                    
            }
            sr.Close();
            fs.Close();            
        }
    }
}
