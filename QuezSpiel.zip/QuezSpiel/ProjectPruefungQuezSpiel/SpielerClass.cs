﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectPruefungQuezSpiel
{
    public class SpielerClass
    {
        private string id, nickName, loginName;

        public SpielerClass() { }
        public SpielerClass(string id, string nickName, string loginName)
        {
            this.Id = id;
            this.NickName = nickName;
            this.LoginName = loginName;
        }

        public string Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string LoginName
        {
            get
            {
                return loginName;
            }

            set
            {
                loginName = value;
            }
        }

        public string NickName
        {
            get
            {
                return nickName;
            }

            set
            {
                nickName = value;
            }
        }
        public void setAll(List<string> ls)
        {
            id = ls[0];
            nickName = ls[1];
            loginName = ls[2];
        }
    }
}
