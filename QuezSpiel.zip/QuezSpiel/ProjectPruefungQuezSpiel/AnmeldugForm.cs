﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectPruefungQuezSpiel
{
    public partial class AnmeldugForm : Form
    {
        DBBefehleClass db = new DBBefehleClass();
        public AnmeldugForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) //SpeicherButton
        {
            if (db.pruefNickName(textBox1.Text))
                {
                if (db.pruefLogName(textBox2.Text))
                {
                    if (pruefPass())
                    {
                        db.saveUser(textBox1.Text, textBox2.Text, textBox3.Text);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show($" Passwörte müssen identisch sein und Mindesten 5 Zeichen beinhalten ");
                    }
                }
                else
                {
                    MessageBox.Show($"Login Name {textBox2.Text} ist schon vergeben");
                }
            }
            else
            {
                MessageBox.Show($"Spieler Name {textBox1.Text} ist schon vergeben");
            } 
        }

        public bool pruefPass ()//Passwortprüfung
        {
            if (textBox3.Text == textBox4.Text && textBox3.Text.Length > 4) return true;
            else return false;
        }     
    }
     
}
