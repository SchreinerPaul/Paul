drop database if  exists QuezSpiel;
create  database QuezSpiel;
use  QuezSpiel;


create Table spieler(
ID integer primary key auto_increment,
NickName varchar(16),
LoginName varchar(16)
);

create Table passwoerter(
ID integer primary key auto_increment,
ID_Spieler integer,
Passwort varchar(16),
foreign key (ID_Spieler) references spieler(id)
);

create Table highscore(
ID integer primary key auto_increment,
ID_Spieler integer,
Highscore integer,
foreign key (ID_Spieler) references spieler(id)
);

create Table laende(
ID integer primary key auto_increment,
Land varchar(50),
Hauptstadt varchar(50),
FlaggPfad varchar(50)
);


