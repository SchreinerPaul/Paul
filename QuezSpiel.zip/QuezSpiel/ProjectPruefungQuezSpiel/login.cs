﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectPruefungQuezSpiel
{

    public partial class login : Form
    {
        DBBefehleClass db = new DBBefehleClass();
        Form1 f1 ;       
        public login(Form1 f)
        {
            InitializeComponent();
            f1 = f;
            textBox1.Text = "";
            textBox2.Text = "";

        }

        private void button1_Click(object sender, EventArgs e) //login
        {
            if (!db.log(textBox1.Text, textBox2.Text))
            {
                MessageBox.Show("Loginname oder Passwort sind falsch");
                f1.log = false;
            }
            else
            {
                f1.spl = db.loadSpieler(textBox1.Text);
                f1.log = true;
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)//Starten Form Anmeldung
        {
            AnmeldugForm an = new AnmeldugForm();
            this.Hide();
            an.ShowDialog();
            this.Show();
            textBox1.Text = "";
            textBox2.Text = "";
        }
    }
}