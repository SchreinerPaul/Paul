﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectPruefungQuezSpiel
{
    class DBBefehleClass
    {
        private MySqlConnection dbConnection, dbConnect;

        public void datenbankCheck() //Datenbank wird erstelt, falls er nicht da ist 
        { 
            try
            {                
                dbConnect = new MySqlConnection("SERVER=127.0.0.1; UID=root; PASSWORD=root; SSLMODE=NONE");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }            
            MySqlCommand comm = dbConnect.CreateCommand();
            comm.CommandText = "create  database if not exists QuezSpiel; " +
                               "use QuezSpiel; " +
                               "create Table if not exists spieler(ID integer primary key auto_increment," +
                                    "NickName varchar(16)," +
                                    "LoginName varchar(16));" +
                               "create Table if not exists passwoerter(ID integer primary key auto_increment," +
                                    "ID_Spieler integer," +
                                    "Passwort varchar(16)," +
                                    "foreign key(ID_Spieler) references spieler(id));" +
                               "create Table if not exists highscore(ID integer primary key auto_increment," +
                                    "ID_Spieler integer," +
                                    "Highscore integer(16)," +
                                    "foreign key(ID_Spieler) references spieler(id));" +
                                    "drop table if exists laende;" +
                               "create Table laende(ID integer primary key auto_increment," +
                                    "Land varchar(50)," +
                                    "Hauptstadt varchar(50)," +
                                    "FlaggPfad varchar(50)); ";
            dbConnect.Open();
            comm.ExecuteNonQuery();
            dbConnect.Close();
        }

        public void saveLandFlagStadt(string land, string hauptstadt, string pfad) //Tabbele Laender wird mit Daten aus Datei Mappe 2 gefühlt
        {
            mySQLBefehl("INSERT INTO laende Values (null, '" + land
                        + "' , '" + hauptstadt
                        + "' ,'" + pfad
                        + "');");
        }
        
        public void dbOeffnen()
        {
            try
            {
                dbConnection = new MySqlConnection(
                    "SERVER=127.0.0.1; DATABASE=QuezSpiel;"
                    + "UID=root; PASSWORD=root; SSLMODE=NONE");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void dbSchliessen()
        {
            dbConnection.Close();
        }
        public void mySQLBefehl(string befehl) 
        {
            dbOeffnen();
            MySqlCommand comm = dbConnection.CreateCommand();
            comm.CommandText = befehl;
            dbConnection.Open();
            comm.ExecuteNonQuery();
            dbConnection.Close();
            dbSchliessen();
        }
        
        public List<List<string>> load(string befehl)
        {
            List<List<string>> liLOAD = new List<List<string>>();
            dbOeffnen();
            MySqlCommand comm = dbConnection.CreateCommand();
            comm.CommandText = befehl;
            dbConnection.Open();
            MySqlDataReader reader = comm.ExecuteReader();
            while (reader.Read())
            {
                List<string> zeile = new List<string>();
                string wort;
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    wort = reader.GetString(i);
                    zeile.Add(wort);
                }
                liLOAD.Add(zeile);
            }
            reader.Close();
            dbConnection.Close();
            dbSchliessen();
            return liLOAD;
        } //Ergebnis eine Nachfrage wir in Liste von listen zurückgegeben
        public bool log(string logName, string pass) // Vergleich Login und Passwort mit Dattenbank
        {
            bool ret = false;
            List<List<string>> ps = load(
                $"Select passwoerter.passwort  from passwoerter , spieler " +
                $"where passwoerter.ID_Spieler like " +
                $"(select spieler.id where spieler.LoginName like '{logName}');");
            if (ps.Count != 0)
                if (ps[0][0] == pass)
                    ret = true;
            return ret;
        }
        public List<LaenderClass> laenderIN()//fühlt  eine Liste von Klasse Laener mit daten aus datenbank auf
        {
            List<LaenderClass> spiel = new List<LaenderClass>();
            List < List<string> >  liLOAD = load("select * from laende");
            foreach (List<string> zeile in liLOAD)
            {
                spiel.Add(new LaenderClass(zeile[0], zeile[1], zeile[2], zeile[3]));                
            }
            return spiel;
        }
        public void saveErgabniss(string spielerID, int score)//speicher Ergebnisse in Datenbank ein
        {
            mySQLBefehl($"insert into highscore values (null, '{spielerID}', '{score}')");
        }
        public SpielerClass loadSpieler(string logName) // läd Daten der Spieler mit gegebenen Loganame aus Datenbank ein
        {
            List<List<string>> tabelle = load($"select * from spieler where LoginName = '{logName}'"); 
            SpielerClass spieler = new SpielerClass(tabelle[0][0], tabelle[0][1], tabelle[0][2]);
            return spieler;
        }
        public List<List<string>> bestForAllListe()//Lifern alle Ergebnisse aus
        {
            List<List<string>> ret = load("select spieler.Nickname, highscore.highscore from spieler, highscore " +
                "where spieler.id like highscore.ID_Spieler order by highscore.highscore desc;");
            return ret;
        }
        public List<List<string>> bestForMeListe(string nickName)//Lifern alle Ergebnisse für einen Spieler aus
        {
            List<List<string>> ret = load($"select spieler.Nickname, highscore.highscore from spieler, highscore " +
                $"where spieler.id like highscore.ID_Spieler and spieler.Nickname like '{nickName}' " +
                $"order by highscore.highscore desc;");
            return ret;
        }       
        public void saveUser(string nick, string logN, string pass) //Fühgt neuen User ein
        {
            mySQLBefehl($"insert into spieler values (null, '{nick}', '{logN}')");
            List<List<string>> ll = load($"select id from spieler where nickname like '{nick}';");
            mySQLBefehl($"insert into passwoerter values (null, '{ll[0][0]}', '{pass}')");
        }
        public bool pruefNickName(string nick) //Prüft, ob Nickname in Datenbank schon vorhandet ist
        {
            List<List<string>> ll = load($"select * from spieler where nickname like '{nick}';");
            if (ll.Count > 0) return false;
            else return true;
        }
        public bool pruefLogName(string logN)//Prüft, ob LogName in Datenbank schon vorhandet ist
        {
            List<List<string>> ll = load($"select * from spieler where LoginName like '{logN}';");
            if (ll.Count > 0) return false;
            else return true;
        }
       
    }
}
