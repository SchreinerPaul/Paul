﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectPruefungQuezSpiel
{
    class LaenderClass
    {
        private string id, land, hauptstadt, flagge;

        public LaenderClass(string id, string land, string hauptstadt, string flagge)
        {
            this.Id = id;
            this.Land = land;
            this.Hauptstadt = hauptstadt;
            this.Flagge = flagge;
        }

        public string Flagge
        {
            get
            {
                return flagge;
            }

            set
            {
                flagge = value;
            }
        }

        public string Hauptstadt
        {
            get
            {
                return hauptstadt;
            }

            set
            {
                hauptstadt = value;
            }
        }

        public string Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string Land
        {
            get
            {
                return land;
            }

            set
            {
                land = value;
            }
        }
        public void setALL(List<string> zeile)
        {
            this.Id = zeile[0];
            this.Land = zeile[1];
            this.Hauptstadt = zeile[2];
            this.Flagge = zeile[3];
        }
    }
}
